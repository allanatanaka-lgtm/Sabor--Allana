// Listas de imagens de exemplo para cada categoria irem alternando entre si
const imagensCategorias = [
    // Práticas
    [
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?auto=format&fit=crop&w=200&q=80"
    ],
    // Doces
    [
        "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=200&q=80"
    ],
    // Saudáveis
    [
        "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=200&q=80"
    ],
    // Tradicionais
    [
        "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=200&q=80"
    ]
];

let indicesAtuais = [0, 0, 0, 0];
let cardAtivo = 0;
const cards = document.querySelectorAll('.category-card');

// Função para alternar as imagens automaticamente a cada 3 segundos
function alternarImagens() {
    for (let i = 0; i < imagensCategorias.length; i++) {
        indicesAtuais[i] = (indicesAtuais[i] + 1) % imagensCategorias[i].length;
        let imgElement = document.getElementById(`img-cat-${i}`);
        
        // Efeito de transição suave
        imgElement.style.opacity = '0';
        setTimeout(() => {
            imgElement.src = imagensCategorias[i][indicesAtuais[i]];
            imgElement.style.opacity = '1';
        }, 250);
    }

    // Alterna também o card ativo visualmente de forma rotativa
    cards[cardAtivo].classList.remove('active');
    cardAtivo = (cardAtivo + 1) % cards.length;
    cards[cardAtivo].classList.add('active');
}

// Inicia o intervalo do carrossel (a cada 3000ms / 3 segundos)
setInterval(alternarImagens, 3000);

// Permitir clique manual no card para selecionar a categoria
function selecionarCategoria(index) {
    cards.forEach(c => c.classList.remove('active'));
    cards[index].classList.add('active');
    cardAtivo = index;
}
// Base de dados simulada para mostrar os ingredientes e modo de preparo
const bancoReceitas = {
    "Frango com Legumes": {
        img: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
        ingredientes: [
            "500g de peito de frango em cubos",
            "1 abobrinha picada",
            "1 cenoura em rodelas",
            "2 dentes de alho picados",
            "Azeite, sal e pimenta-do-reino a gosto"
        ],
        passos: [
            "Tempere o frango com alho, sal e pimenta.",
            "Em uma frigideira grande, doure o frango no azeite.",
            "Adicione a cenoura e refogue por 5 minutos.",
            "Acrescente a abobrinha, misture bem e deixe cozinhar até amaciarem."
        ]
    },
    "Bolo de Chocolate": {
        img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80",
        ingredientes: [
            "3 ovos",
            "2 xícaras de farinha de trigo",
            "1 xícara de açúcar",
            "1 xícara de achocolatado em pó",
            "1 xícara de leite",
            "1 colher de sopa de fermento em pó"
        ],
        passos: [
            "Bata no liquidificador os ovos, o açúcar, o achocolatado e o leite.",
            "Despeje em uma tigela e misture a farinha de trigo delicadamente.",
            "Adicione o fermento em pó por último e mexa levemente.",
            "Asse em forno preaquecido a 180°C por cerca de 40 minutos."
        ]
    },
    "Salada de Quinoa": {
        img: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80",
        ingredientes: [
            "1 xícara de quinoa cozida",
            "1 tomate picado em cubos",
            "1 pepino japonês picado",
            "Folhas de hortelã e salsinha picadas",
            "Suco de 1 limão e azeite"
        ],
        passos: [
            "Cozinhe a quinoa em água e sal por 15 minutos e deixe esfriar.",
            "Misture a quinoa com o tomate e o pepino em uma tigela.",
            "Tempere com o suco de limão, azeite, sal e ervas frescas.",
            "Sirva gelada."
        ]
    },
    "Lasanha à Bolonhesa": {
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5WkTvbdOevAdJXkkadAvOLH6eutLRK6mdu-YW9hGjDA&s=10",
        ingredientes: [
            "1 pacote de massa para lasanha",
            "500g de carne moída",
            "2 latas de molho de tomate",
            "300g de queijo muçarela fatiado",
            "300g de presunto fatiado"
        ],
        passos: [
            "Prepare o molho de carne moída refogando com temperos e o molho de tomate.",
            "Em uma travessa, alterne camadas de molho, massa, presunto e queijo.",
            "Repita as camadas até preencher a travessa, finalizando com queijo.",
            "Leve ao forno a 200°C por 30 minutos até gratinar."
        ]
    },
}
// Função para abrir os detalhes da receita
function abrirReceita(nome) {
    localStorage.setItem('receitaSelecionada', nome);
    window.location.href = 'detalhes.html';
}

// Funcionalidade do botão de favoritar (coração) com memória
function toggleFavorito(botao) {
    const icone = botao.querySelector('i');
    icone.classList.toggle('fa-regular');
    icone.classList.toggle('fa-solid');
    
    if (icone.classList.contains('fa-solid')) {
        botao.style.color = '#e63946';
    } else {
        botao.style.color = 'var(--primary-color)';
    }
}

// Configuração das setas do carrossel de filtros (caso existam na página)
const scrollLeftBtn = document.getElementById('scrollLeftBtn');
const scrollRightBtn = document.getElementById('scrollRightBtn');
const filterContainer = document.getElementById('filterContainer');

if (scrollLeftBtn && scrollRightBtn && filterContainer) {
    scrollLeftBtn.addEventListener('click', () => {
        filterContainer.scrollBy({ left: -200, behavior: 'smooth' });
    });
    scrollRightBtn.addEventListener('click', () => {
        filterContainer.scrollBy({ left: 200, behavior: 'smooth' });
    });
}

// Filtro de categorias por botões (pills)
const filterPills = document.querySelectorAll('.filter-pill');
const recipeCards = document.querySelectorAll('.recipe-card');

filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
        filterPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');

        const categoriaSelecionada = pill.getAttribute('data-categoria');

        recipeCards.forEach(card => {
            const categoriaCard = card.getAttribute('data-categoria');
            if (categoriaSelecionada === 'todas' || categoriaCard === categoriaSelecionada) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});
